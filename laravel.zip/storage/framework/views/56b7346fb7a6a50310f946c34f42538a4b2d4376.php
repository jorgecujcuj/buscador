        <div class="form-group row">
            <label for="tzutujil" class="col-md-4 col-form-label text-md-right"><?php echo e(__("Tz'utujil:")); ?></label>

            <div class="col-md-6">
                <input id="tzutujil" type="text" class="form-control <?php $__errorArgs = ['tzutujil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tzutujil" value="<?php echo e(old('tzutujil',$dato->tzutujil)); ?>"  autofocus>

                 <?php $__errorArgs = ['tzutujil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-group row">
            <label for="spanish" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Español:')); ?></label>

            <div class="col-md-6">
                <input id="spanish" type="text" class="form-control <?php $__errorArgs = ['spanish'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="spanish" value="<?php echo e(old('spanish',$dato->spanish)); ?>"  autofocus>

                 <?php $__errorArgs = ['spanish'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-group row">
            <label for="ingles" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Ingles:')); ?></label>

            <div class="col-md-6">
                <input id="ingles" type="text" class="form-control <?php $__errorArgs = ['ingles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ingles" value="<?php echo e(old('ingles',$dato->ingles)); ?>"  autofocus>

                 <?php $__errorArgs = ['ingles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-group row">
            <label for="hashtag" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Hashtag:')); ?></label>

            <div class="col-md-6">
                <input id="hashtag" type="text" class="form-control <?php $__errorArgs = ['hashtag'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="hashtag" value="<?php echo e(old('hashtag',$dato->hashtag)); ?>"  autofocus>

                 <?php $__errorArgs = ['hashtag'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-group">
            <input type="hidden" name="iduser" class="form-control"value="<?php echo e(Auth::user()->id); ?>">
        </div>

        <div class="box-footer mt20">
            <button type="submit" class="btn btn-primary">Guardar</button>
            <a class="btn btn-danger" href="<?php echo e(route('datos.index')); ?>"> Regresar</a>
        </div>
<?php /**PATH C:\wamp64\www\BUSCADOR\laravel\resources\views/dato/form.blade.php ENDPATH**/ ?>