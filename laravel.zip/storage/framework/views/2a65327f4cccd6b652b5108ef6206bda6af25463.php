<?php $__env->startSection('template_title'); ?>
    Dato
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
        <div class="section-header">
            <h3 class="page__heading">Datos del diccionario</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                                
                                <div class="form-row">
                                    <div class="col-xs-12 col-md-1">
                                            <a href="<?php echo e(route('datos.create')); ?>" class="btn btn-primary " >
                                            <?php echo e(__('Crear')); ?>

                                            </a>
                                    </div>
                                </div>
                                <br>
                                <form action="<?php echo e(route('datos.index')); ?>" method="get">
                                    <div class="form-row">
                                        <div class="col-xs-6 col-md-1">     
                                            <input type="submit" class="btn btn-primary" Value="Buscar">
                                        </div>

                                            <div class="col-xs-12 col-md-4">
                                                <input type="text" class="form-control" placeholder="Ingrese una palabra" id="texto" name="texto" value="<?php echo e($texto); ?>">
                                            </div>  
                                            
                                        </div>        
                                </form>
                                
                                <br>
                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success">
                                    <p><?php echo e($message); ?></p>
                                </div>
                            <?php endif; ?>


                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead class="thead">
                                        <tr>
                                            <th>No</th>
                                            <th>Tzutujil</th>
                                            <th>Spanish</th>
                                            <th>Ingles</th>
                                            <th>Hashtag</th>
                                            <th>Iduser</th>
                                            <th>Usuer</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(++$i); ?></td>
                                                
                                                <td><?php echo e($dato->tzutujil); ?></td>
                                                <td><?php echo e($dato->spanish); ?></td>
                                                <td><?php echo e($dato->ingles); ?></td>
                                                <td><?php echo e($dato->hashtag); ?></td>
                                                <td><?php echo e($dato->iduser); ?></td>
                                                <td><?php echo e($dato->user->name); ?></td>

                                                <td>
                                                    <form action="<?php echo e(route('datos.destroy',$dato->id)); ?>" method="POST">
                                                        <a class="btn btn-sm btn-primary " href="<?php echo e(route('datos.show',$dato->id)); ?>"><i class="fa fa-fw fa-eye"></i> Ver</a>
                                                        <a class="btn btn-sm btn-success" href="<?php echo e(route('datos.edit',$dato->id)); ?>"><i class="fa fa-fw fa-edit"></i> Editar</a>
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i> Eliminar</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="pagination justify-content-end">
                                <?php echo $datos->links(); ?>

                            </div>
                
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\BUSCADOR\laravel\resources\views/dato/index.blade.php ENDPATH**/ ?>