<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1">-->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />

    <!-- Bootstrap icons-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome icons (free version)-->
    <script src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" crossorigin="anonymous"></script>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    
    <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css" />
    
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="<?php echo e(asset('web/css/styles.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    
</head>
<body>
    
        <!-- Navigation-->
    <div id="app">
        <nav class="navbar navbar-expand-lg navbar-light" id="mainNav">
                
                <div class="container px-4 px-lg-5">
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><?php echo e(config('app.name', 'Laravel')); ?></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                        Menu
                        <i class="fas fa-bars"></i>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarResponsive">
                        <ul class="navbar-nav ms-auto py-4 py-lg-0">
                                <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="<?php echo e(url('buscas')); ?>"><?php echo e(__('Inicio')); ?></a></li>
                                <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="<?php echo e(url('nosotros')); ?>"><?php echo e(__('Nosotros')); ?></a></li>
                                <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="<?php echo e(route('crearContactos.create')); ?>"><?php echo e(__('Contactos')); ?></a></li>

                                
                            <?php if(Auth::check()): ?>
                            <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="<?php echo e(url('datos')); ?>"><?php echo e(__('Datos')); ?></a></li>
                            <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="<?php echo e(url('contactos')); ?>"><?php echo e(__('Mensajes')); ?></a></li>
                            <?php endif; ?>

                            <?php if(auth()->guard()->guest()): ?>
                                <?php if(Route::has('login')): ?>
                                <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="<?php echo e(route('login')); ?>"><?php echo e(__('Iniciar Sesion')); ?></a></li>
                                <?php endif; ?>

                                <?php if(Route::has('register')): ?>
                                <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="<?php echo e(route('register')); ?>"><?php echo e(__('Registrase')); ?></a></li>
                                <?php endif; ?>
                            <?php else: ?>
                            <li class="nav-item dropdown">
                                    <a id="navbarDropdown" class="nav-link dropdown-toggle px-lg-3 py-3 py-lg-4" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                        <?php echo e(Auth::user()->name); ?>

                                    </a>
                                
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                            document.getElementById('logout-form').submit();">
                                                <?php echo e(__('Cerrar Sesiono')); ?>

                                            </a>

                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                </div>
                            </li>      
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
        </nav>
    </div> 
        <!-- Masthead-->
        <?php echo $__env->yieldContent('contentuno'); ?>
     
        <!-- Icons Grid-->
        <section class="features-icons bg-light text-center">
            <div class="container">
                <div class="row">

                    <div class="col">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>

                </div>
            </div>
        </section>

        <?php echo $__env->yieldContent('contentdos'); ?>
        
        <section class="bs-calltoaction bs-calltoaction-default text-white text-center" id="signup">
            <div class="container position-relative">
                <div class="row justify-content-center">
                    <div class="col-xl-6">
                        <h2 class="mb-4">Ready to get started?</h2>

                        <form class="form-subscribe" id="contactFormFooter" data-sb-form-api-token="API_TOKEN">
                        
                        </form>
                    </div>
                </div>
            </div>
        </section>

        <!-- Footer-->
        <footer class="footer bg-light">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 h-100 text-center text-lg-start my-auto">
                        <ul class="list-inline mb-2">
                            <li class="list-inline-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('Inicio')); ?></a></li>
                            <li class="list-inline-item">⋅</li>
                            <li class="list-inline-item"><a href="<?php echo e(url('nosotros')); ?>"><?php echo e(__('Nosotros')); ?></a></li>
                            <li class="list-inline-item">⋅</li>
                            <li class="list-inline-item"><a href="<?php echo e(route('contactos.create')); ?>"><?php echo e(__('Contactos')); ?></a></li>
                            <li class="list-inline-item">⋅</li>
                            <li class="list-inline-item"><a href="<?php echo e(route('login')); ?>"><?php echo e(__('Inicciar Sesion')); ?></a></li>
                        </ul>
                        <p class="text-muted small mb-4 mb-lg-0">&copy; Your Website 2021. All Rights Reserved.</p>
                    </div>
                    <div class="col-lg-6 h-100 text-center text-lg-end my-auto">
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item me-4">
                                <a href="https://www.facebook.com/profile.php?id=100068375786650"><i class="bi-facebook fs-3"></i></a>
                            </li>
                            <li class="list-inline-item me-4">
                                <a href="#!"><i class="bi-twitter fs-3"></i></a>
                            </li>
                            <li class="list-inline-item">
                                <a href="#!"><i class="bi-instagram fs-3"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="<?php echo e(asset( 'web/js/scripts.js')); ?>" defer></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
    
</body>
</html>
<?php /**PATH C:\wamp64\www\BUSCADOR\laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>